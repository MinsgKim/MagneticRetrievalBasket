clear; clc; clf;
Simscape_Preprocessing;

x_init(1:Fixed.num_links) = pi * (2* rand(1, Fixed.num_links) - 1);
x_init(Fixed.num_links+1: 2*Fixed.num_links+1) = 5000 * (7 * rand(1,Fixed.num_links+1)) * Fixed.PlateVolume;

% optimizing boundaries
lb = [repmat(-pi, 1, Fixed.num_links), repmat(5e3, 1, Fixed.num_links +1) * Fixed.PlateVolume];
ub = [repmat(pi, 1, Fixed.num_links), repmat(5e4, 1, Fixed.num_links +1) * Fixed.PlateVolume];

% % optimized parameters storage
% num_iterations = 2; % iterations
% x_results = zeros(num_iterations, length(x_init));
% cost_values = zeros(num_iterations, 1);

%%
% option setup
options = optimoptions('fmincon', 'Display', 'iter', 'StepTolerance', 1e-6, 'FunctionTolerance', 1e-6, ...
    'MaxFunctionEvaluations', 1e5, 'OptimalityTolerance', 1e-6, ...
    'Algorithm', 'interior-point', "EnableFeasibilityMode", true, ...
    "SubproblemAlgorithm","cg");

tic;
[x_opt, f_val] = fmincon(@(x) Simscape_Fitness(x, SimParams, Fixed), ...
    x_init, [], [], [], [], lb, ub, [], options);


fprintf('==== Optimization Finished ====\n');
fprintf('Best Cost (fval_opt): %.4f\n', f_val);
disp('Optimized x_opt = [thetaM_1..thetaM_n]:');
disp(rad2deg(x_opt(1:Fixed.num_links)));
disp('Optimized x_opt = [psi_1..psi_n]:');
disp(x_opt(Fixed.num_links+1:end)/Fixed.PlateVolume);
toc;

% examination
% 
% Optim.Angle = rad2deg(x_opt(1:Fixed.num_links));
% Optim.Magnitude = x_opt(Fixed.num_links+1:end);
% Optim.DipoleMoment_HomeConfig = Cal_DipoleMoment(Optim.Angle, Optim.Magnitude, "AngleUnit", "Degree");
% 
% Data_Optim = MagneticBasket_MatlabSimulation(Funs, SimOptions, Optim.DipoleMoment_HomeConfig);
% 
% PlayVideo(Data_Optim, Funs, Optim.DipoleMoment_HomeConfig, "FrameNum", 50, "Record", "no")


%% Check
Simscape_Fitness(x_opt, SimParams, Fixed, "DispInfo", "yes", "GUI", "on") 


%% 1st examination
% clear; clc; clf;
% Preprocessing;

clf;

% x_test(1:Fixed.num_links) = pi * (2* rand(1, Fixed.num_links) - 1);
% x_test(Fixed.num_links+1: 2*Fixed.num_links) = 5000 * (7 * rand(1,Fixed.num_links) + 1) * Fixed.PlateVolume;

% x_test(1:Fixed.num_links) = [54.3722 38.0691   39.9403   60.6414  -66.1721  -42.7437  -50.2522];
% x_test(Fixed.num_links+1:2*Fixed.num_links) = [4.9519    4.9666    4.9663    4.9226    4.9734    4.9835    4.9838] * 1e+4 * Fixed.PlateVolume;

% x_test(1:Fixed.num_links) = linspace(0, 340, 7) + 10;
% x_test(Fixed.num_links+1:2*Fixed.num_links) = repmat(5e4, 1, 7) * Fixed.PlateVolume;

x_test(1:Fixed.num_links) = [50 40 40 60 -60 -40 -50];
% x_test(1:Fixed.num_links) = [40 40 40 40 -40 -40 -40];
% x_test(1:Fixed.num_links) = [50 50 50 50 -50 -50 -50];
% x_test(1:Fixed.num_links) = [60 60 60 60 -60 -60 -60];
x_test(Fixed.num_links+1:2*Fixed.num_links) = repmat(5e4,1,7) * Fixed.PlateVolume;

% Fitness = Find_Fitness(x_test, Fixed.num_links, Funs, SimOptions);

% Fitness = -Find_Fitness(x_opt, Fixed.num_links, Funs, SimOptions);

Test.Angle = rad2deg(x_test(1:Fixed.num_links));
Test.Angle = x_test(1:Fixed.num_links);
Test.Magnitude = x_test(Fixed.num_links+1:end);
Test.DM_HC = Cal_DipoleMoment(Test.Angle, Test.Magnitude, "AngleUnit", "Degree");

Data_Test = MagneticBasket_MatlabSimulation(Funs, SimOptions, Test.DM_HC);
PlayVideo(Data_Test, Funs, Test.DM_HC, "FrameNum", 50, "Record", "no")

% Data_Optim = MagneticBasket_MatlabSimulation(Funs, SimOptions, Optim.DipoleMoment_HomeConfig);
% 
% PlayVideo(Data_Optim, Funs, Optim.DipoleMoment_HomeConfig, "FrameNum", 50, "Record", "no")

%% Fabrication Parameter Decision
clear; clc;


% sample dimension
w = 3.2e-3;
l = 2.1e-3;
t = 0.5e-3;

% magnetization angles
theta_M = deg2rad([40, 50, 60]);

% manually changeable param
n = 5;

% design parameters;

l_proj = n*t*cos(theta_M)+l*sin(theta_M);

h1 = n*t./sin(theta_M);

eps = 0.3e-3;
a1 = 0.05.*l_proj;
a2 = 0.2e-3;

h2 = l_proj.*cot(theta_M)+n*t.*sin(theta_M) + eps;

h3 = h2-(a2+n*t)./sin(theta_M);

