function MB = Call_MagneticBasket_Params

    % Plate Geometry
    MB.PlateLength = 2.35 * 1e-3;
    MB.PlateWidth = 3 * 1e-3;
    MB.PlateThickness = 0.7 * 1e-3;
    MB.PlateVolume = MB.PlateLength * MB.PlateWidth * MB.PlateThickness;
    MB.PlateDensity = 2000;
        
    % Plate Magnet Properties
    MB.Plate_MagnetMagnitude = ones(1,6) * 4.4942*1e-4;

    % Source Magnet Properties
    MB.BField_Magnitude = 1;
    MB.Source_MagnetMagnitude = 1; 

    % Mechanical Properties
    MB.Stiffness = 7e-8; % [Nm/(radian)]
    MB.Damping = 7e-9; % [Nm/(radian/s)]
    MB.Stiffness_upper = 7e-8*2;
    MB.Damping_upper = 7e-9;
    MB.Transition_upper = 0.01;

    % Simulink Parameters
    MB.Opt_EndTime = 0.15; % [sec]
    MB.Cal_EndTime = 5; % [sec]
    
end