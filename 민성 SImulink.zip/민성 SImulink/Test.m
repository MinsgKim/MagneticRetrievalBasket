clear;clc;
Sim = Call_MagneticBasket_Params;
open("Optimization_250328.slx")
open("Calibration_250328.slx")

%% Example
% 예를 들어 입력 변수가 Plate들의 각도라면 Call_MagnetBasket_Params안의 값을 바꾸지 말고
% Sim = Call_MagneticBasket_Params; 이렇게 불러온 후 Sim.Angle = ~ 바꾸면됨
% Sim_Optimization/Sim_Calibration이 Simulink 실행시키는 함수, 반환하는 값은 Plate의 각도(rad)
% 원하는 변수를 Sim.~ = 원하는값 으로 바꾸고 위 함수안에 바뀐 Sim을 넣어주면 그 변수들에 따라 시뮬레이션
% 모델 열려있어야함
% 나중에 최적화할때는 Sim_Optimization/Calibration Options 다 끄면됨(GUI, DisInfo)

%% Optimization
Sim.Angle = [1 1 1 -1 -1 -1]*pi/2;
[Upper_q, Lower_q] = Sim_Optimization(Sim, "GUI", "on", "DispInfo", "yes");

%% Calibration
% Calibration은 어떻게 실험할건지 정해서 그에 맞게 모델을 변경해야함
Sim.Plate_MagnetMagnitude = ones(1,6)*1e-4;
Sim.Stiffness = 7e-8;
Sim.Stiffness_upper = 7e-8*2;
Sim.Cal_EndTime = 3;
q = Sim_Calibration(Sim, "GUI", "on", "DispInfo", "yes");