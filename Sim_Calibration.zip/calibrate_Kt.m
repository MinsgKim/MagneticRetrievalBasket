function cost = calibrate_Kt(x, q_measured, SimParams, Options)

arguments

    x (1,:) double  % [dipole moment of each link (1x6), Kt]
    q_measured (:,:,:) double
    SimParams (1,1) struct
    Options.DispInfo {mustBeMember(Options.DispInfo, {'yes', 'no'})} = 'no'
    Options.GUI {mustBeMember(Options.GUI, {'on', 'off'})} = 'off'

end

%------x axis------%
    
    SimParams.Stiffness = x(end-1) * 1e-6;
    SimParams.Stiffness_upper = x(end)*1e-6;
    SimParams.Plate_MagnetMagnitude = x(1:6)*1e-4;
    
    % matlab 작업공간에 'Sim'라는 변수 넘김
    % simulink가 함수 작업공간이 아니라 기본 base 작업공간의 'Sim'를 참조하기 때문
    % assignin("base", 'Sim', SimParams);
    
    % Simulink simulation
    ModelName = 'Calibration_250328';
    if strcmp(Options.GUI, 'off')
        set_param(ModelName, 'SimMechanicsOpenEditorOnUpdate', 'off');
    else
        set_param(ModelName, 'SimMechanicsOpenEditorOnUpdate', 'on');
    end
    
    for i=1:3
    
        SimParams.Source_Angle = -90;
        SimParams.Source_Distance_x = 80-10*i;
        SimParams.Source_Distance_z = 10;
        SimParams.Cal_EndTime = 0.5;
        
        
        assignin("base", 'Sim', SimParams)
        SimOut = sim(ModelName);
        q = SimOut.q.Data(end,:);
        
        % T = toc;
        
        cost(i) = norm(abs(-q - q_measured(:,:,i)));
    
    end
    
    for i=1:3
    
        SimParams.Source_Angle = 180;
        SimParams.Source_Distance_x = 80-10*i;
        SimParams.Source_Distance_z = 15;
        SimParams.Cal_EndTime = 0.15;
        
        assignin("base", 'Sim', SimParams)
        SimOut = sim(ModelName);
        q = SimOut.q.Data(end,:);
        
        % T = toc;
        
        cost(i+3) = norm(abs(-q - q_measured(:,:,i+3)));
    
    end
    
    cost = cost.^2;
    
    cost = sum(cost, "all");


end